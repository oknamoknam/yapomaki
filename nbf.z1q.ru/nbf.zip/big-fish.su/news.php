<?php
	include_once('inc/jcart.php');
	session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
	<style type="text/css" media="all"><!--
.ds1 /*agl rulekind: base;*/ { color: #f00; }
.dsR2 /*agl rulekind: base;*/ { width: 812px; height: 215px; }
.dsR5 /*agl rulekind: base;*/ { position: absolute; top: 0; left: 286px; width: 525px; height: 207px; }
.dsR6 /*agl rulekind: base;*/ { position: absolute; top: 0; left: 0; width: 248px; height: 172px; }
.dsR14 /*agl rulekind: base;*/ { width: 810px; height: 209px; }
.dsR17 /*agl rulekind: base;*/ { position: absolute; top: 0; left: 284px; width: 525px; height: 207px; }
.dsR19 /*agl rulekind: base;*/ { position: absolute; top: 0; left: 0; width: 274px; height: 168px; }
.dsR74 /*agl rulekind: base;*/ { position: absolute; top: 0; left: 184px; width: 625px; height: 207px; }
.dsR75 /*agl rulekind: base;*/ { width: 810px; height: 208px; }
.dsR150 /*agl rulekind: base;*/ { position: absolute; top: 0; left: 0; width: 812px; height: 42px; }
.dsR167 /*agl rulekind: base;*/ { width: 815px; height: 599px; }
.dsR225 /*agl rulekind: base;*/ { position: absolute; top: 0; left: 0; width: 172px; height: 80px; }
.dsR330 /*agl rulekind: base;*/ { position: absolute; top: 86px; left: 0; width: 208px; height: 124px; }
.dsR331 /*agl rulekind: base;*/ { position: absolute; top: 88px; left: 0; width: 204px; height: 122px; }
.dsR342 /*agl rulekind: base;*/ { position: absolute; top: 6px; left: 0; width: 170px; height: 64px; }
.dsR353 /*agl rulekind: base;*/ { position: absolute; top: 0; left: 216px; width: 620px; height: 227px; }
.dsR357 /*agl rulekind: base;*/ { width: 846px; height: 228px; }
.dsR358 /*agl rulekind: base;*/ { width: 846px; height: 230px; }
.dsR361 /*agl rulekind: base;*/ { width: 846px; height: 237px; }
.dsR362 /*agl rulekind: base;*/ { width: 846px; height: 233px; }
.dsR363 /*agl rulekind: base;*/ { position: absolute; top: 42px; left: 0; width: 804px; height: 556px; }
.dsR395 /*agl rulekind: base;*/ { position: absolute; top: 0; left: 188px; width: 625px; height: 207px; }
.dsR397 /*agl rulekind: base;*/ { width: 814px; height: 208px; }
.dsR410 /*agl rulekind: base;*/ { position: absolute; top: 12px; left: 2px; width: 178px; height: 146px; }
.dsR698 /*agl rulekind: base;*/ { width: 850px; height: 218px; }
.dsR719 /*agl rulekind: base;*/ { position: absolute; top: 4px; left: 172px; width: 184px; height: 120px; }
.dsR721 /*agl rulekind: base;*/ { position: absolute; top: 80px; left: 2px; width: 152px; height: 137px; }
.dsR732 /*agl rulekind: base;*/ { position: absolute; top: 0; left: 356px; width: 491px; height: 217px; }
.dsR741 /*agl rulekind: base;*/ { position: absolute; top: 131px; left: 170px; width: 186px; height: 68px; }
--></style>
	
	<?php include('core/head.inc') ?>
<body>
<div id="uwc">
<div id="Underwater">
	<div id="Sea">
		<div id="Light"></div>
		<!-- Page centred -->
		<div id="Container">
			<div id="Header">
				<?php include('core/header.inc') ?>
			</div>
			<div id="Menu">
				<ul>
					<?php include('core/menu.inc') ?>
				</ul>
				
				
				<div class="MenuL"></div>
				<div class="MenuR"></div>
			</div>			
			<div id="Page">
				<div id="Content">
				
				<div class="Conent">
					<div class="Title">
						<h1>НОВОСТИ</h1>
					</div>
					</div>
					<div class="Text">
									<span class="datenew">19.05.2015</span>
									<div class="TitleNews"></div>
									<div class="dsR292" style="position:relative;width:823px;height:241px;-adbe-g:p,2,2;">
										<div class="dsR188" cslocked="cslocked" style="position:absolute;top:7px;left:6px;width:178px;height:67px;-adbe-c:c">
											Акция! Сделайте заказ более чем на 1500 рублей и получите в подарок 2 напитка &quot;Vivо&quot; разных вкусов.<br />
											<span class=""></span></div>
										<div style="position:absolute;top:0px;left:202px;width:620px;height:227px;">
											<img src="images/vivo2.jpg" alt="" height="227" width="620" border="0" /></div>
									</div>
									<span class="datenew">17.04.2015</span>
									<div class="TitleNews"></div>
									<div class="dsR292" style="position:relative;width:822px;height:208px;-adbe-g:p,2,2;">
										<div style="position:absolute;top:0px;left:0px;width:1px;height:1px;">
											<img class="dsR187" src="../images/newmenu.jpg" alt="" height="80" width="172" border="0" /></div>
										<div class="dsR188" cslocked="cslocked" style="position:absolute;top:85px;left:6px;width:178px;height:67px;-adbe-c:c">
											Теперь в нашем меню, в категории "KING роллы" Вы можете попробовать новые роллы "Ялта", "Крым" и "Джанкой"!<br />
											<span class=""></span></div>
										<div style="position:absolute;top:0px;left:196px;width:625px;height:207px;">
											<img src="images/nr.jpg" alt="" height="207" width="625" border="0" /></div>
									</div>
					<span class="datenew">07.04.2015</span>
									<div class="TitleNews"></div>
									<div class="dsR292" style="position:relative;width:822px;height:208px;-adbe-g:p,2,2;">
										<div style="position:absolute;top:0px;left:0px;width:1px;height:1px;">
											<img class="dsR187" src="../images/newmenu.jpg" alt="" height="80" width="172" border="0" /></div>
										<div class="dsR188" cslocked="cslocked" style="position:absolute;top:85px;left:6px;width:178px;height:67px;-adbe-c:c">
											Теперь в нашем меню, в разделе "десерты",<br />
											пять видов эксклюзивных десертов ручной работы.<span class=""></span></div>
										<div style="position:absolute;top:0px;left:196px;width:625px;height:207px;">
											<img src="images/desert.jpg" alt="" height="207" width="625" border="0" /></div>
									</div>
									<span class="datenew">07.04.2015</span>
									<div class="TitleNews"></div>
									<div class="dsR292" style="position:relative;width:822px;height:208px;-adbe-g:p,2,2;">
										<div style="position:absolute;top:0px;left:0px;width:1px;height:1px;">
											<img class="dsR187" src="../images/newmenu.jpg" alt="" height="80" width="172" border="0" /></div>
										<div class="dsR188" cslocked="cslocked" style="position:absolute;top:85px;left:6px;width:178px;height:67px;-adbe-c:c">
											Теперь в нашем меню, в разделе "горячее",<br />
											шесть видов колбасок!<span class=""></span></div>
										<div style="position:absolute;top:0px;left:196px;width:625px;height:207px;">
											<img src="images/sk.jpg" alt="" height="207" width="625" border="0" /></div>
									</div>
									<span class="datenew">25.12.2014</span>
									<div class="TitleNews"></div>
									<p>Компания "BIG-FISH" поздравляет Вас с наступающими праздниками и сообщает, что 31-го декабря приём заказов осуществляется до 21:00. Мы начинаем свою работу 1-го января с 13:30.</p>
					                
					                <span class="datenew">01.10.2014</span>
									<div class="TitleNews"></div>
									<p>Режим работы компании "BIG-FISH" изменился. Теперь мы работаем для Вас с 9-ми часов утра до 2-х часов ночи.</p> 
					
									<span class="datenew">19.06.2014</span>
									<div class="TitleNews"></div>
									<img class="dsR187" src="../images/vivo.jpg" alt="" height="231" width="812" border="0" /></p>
					
									<span class="datenew">16.05.2014</span>
									<div class="TitleNews"></div>
									<p>Режим работы компании "BIG-FISH" изменился. Теперь мы работаем для Вас с 8-ми часов утра до 3-х часов ночи.</p> 
					
									
									<span class="datenew">26.03.2014</span>
									<div class="TitleNews"></div>
										<p>Компания "BIG-FISH" рада сообщить Вам, что в зону обслуживания компании вошёл город Мытищи.  </p>
					<span class="datenew">18.03.2014</span>
										<div class="TitleNews"></div>
										<div class="dsR292" style="position:relative;width:846px;height:229px;-adbe-g:p,2,2;">
											<div style="position:absolute;top:0px;left:0px;width:1px;height:1px;">
												<img class="dsR187" src="../images/newmenu.jpg" alt="" height="80" width="172" border="0" /></div>
											<div class="dsR188" cslocked="cslocked" style="position:absolute;top:88px;left:0px;width:204px;height:140px;-adbe-c:c">
												Теперь в нашем меню<br />
												5 новых видов пиццы. Столичная<br />
												Закрытая с мясом<br />
												Закрытая с рыбой<br />
												Кальцоне<br />
												Тутти-Фрутти<span class=""></span></div>
											<div style="position:absolute;top:1px;left:218px;width:620px;height:227px;">
												<img src="images/pizzi.jpg" alt="" height="227" width="620" border="0" /></div>
										</div>
					<span class="datenew">06.03.2014</span>
										<div class="TitleNews"></div>
										<p>Компания "BIG-FISH" рада сообщить Вам, что в зону обслуживания по минимальной сумме заказа - 400 рублей  вошли нижеследующие станции метро: м. Алтуфьево, м. Владыкино, м. Отрадное, м. Свиблово, м. Бабушкинская, м. Медведково, м. Бибирево, м. Ботанический сад, м. Владыкино  </p>
					
					<span class="datenew">26.02.2014</span>
									<div class="TitleNews"></div>
									<div style="position:relative;width:849px;height:228px;-adbe-g:p,2,2;">
										<div class="dsR721" cslocked="cslocked" style="position:absolute;top:14px;left:0px;width:152px;height:92px;-adbe-c:c">
											<div align="left">
												Теперь Вы можете оплатить заказ банковскими картами VISA и MasterCard<br />
												<br />
											</div>
											<span class="datenew"></span></div>
										<div style="position:absolute;top:0px;left:186px;width:620px;height:227px;">
											<img src="images/karti.jpg" alt="" height="227" width="620" border="0" /></div>
									</div>
									<span class="datenew">10.01.2014</span>
									<div class="TitleNews"></div>
									<div class="dsR698" style=" position: relative; -adbe-g: m,2,2;">
										<div class="dsR721" cslocked="cslocked" style="-adbe-c:c;">
											<div align="left">
												СКОРО!<br />
												<span class="ds1"><b>&quot;BIG-WOK&quot;</b></span> -<br />
												Много видов блюд из восточной лапши доставляемые в фирменных<br />
												коробочках.<br />
											</div>
											<span class="datenew"></span></div>
										<div>
											<img class="dsR732" src="../images/wok1.jpg" alt="" height="217" width="491" border="0" /></div>
										<div>
											<img class="dsR225" src="../images/newmenu.jpg" alt="" height="80" width="172" border="0" /></div>
										<div>
											<img class="dsR741" src="../images/wok2.jpg" alt="" height="68" width="186" border="0" /></div>
										<div>
											<img class="dsR719" src="../images/wok_an.gif" alt="" height="120" width="184" border="0" /></div>
									</div>
									
									
									<span class="datenew">31.12.2013</span>
									<div class="TitleNews"></div>
									<div class="dsR361" style=" position: relative; -adbe-g: p,2,2;">
										<div class="dsR331" cslocked="cslocked" style="-adbe-c:c;">
											<div align="left">Новое пиво &quot;AmberWeiss&quot;!<br />
												Сварено по классической технологии производства пшеничного нефильтрованного пива.</div>
											<span class="datenew"></span></div>
										<div>
											<img class="dsR353" src="../images/amber.jpg" alt="" height="227" width="620" border="0" /></div>
										<div>
											<img class="dsR225" src="../images/newmenu.jpg" alt="" height="80" width="172" border="0" /></div>
									</div>
									<span class="datenew">31.12.2013</span>
									<div class="TitleNews"></div>
									<div class="dsR362" style=" position: relative; -adbe-g: p,2,2;">
										<div class="dsR331" cslocked="cslocked" style="-adbe-c:c;">
											<div align="left">Теперь в нашем меню ролл &quot;Вьетнам&quot;!<br />По многочисленным пожеланиям в меню вернулся горячий ролл &quot;Вьетнам&quot;.</div>
											<span class="datenew"></span></div>
										<div>
											<img class="dsR353" src="../images/vietnam.jpg" alt="" border="0" /></div>
										<div>
											<img class="dsR225" src="../images/newmenu.jpg" alt="" height="80" width="172" border="0" /></div>
									</div>
									<span class="datenew">30.12.2013</span>
									<div class="TitleNews"></div>
									<div class="dsR357" style=" position: relative; -adbe-g: p,2,2;">
										<div>
											<img class="dsR225" src="../images/newmenu.jpg" alt="" height="80" width="172" border="0" /></div>
										<div class="dsR331" cslocked="cslocked" style="-adbe-c:c;">
											Новый дункан &quot;Рио&quot;!<br>
											
											Специально к чемпионату мира по футболу в Бразилии. Верим в нашу команду!<span class="datenew"></span></div>
										<div>
											<img class="dsR353" src="../images/rio.jpg" alt="" border="0" /></div>
									</div>
									<span class="datenew">30.12.2013</span>
									<div class="TitleNews"></div>
									<div class="dsR358" style=" position: relative; -adbe-g: p,2,2;">
										<div>
											<img class="dsR225" src="../images/newmenu.jpg" alt="" height="80" width="172" border="0" /></div>
										<div class="dsR330" cslocked="cslocked" style="-adbe-c:c;">Новый ролл &quot;Сочи&quot; ! Попробуйте на вкус жемчужину Чёрного моря. Специально к олимпиаде в Сочи. Верим в российскую сборную!<span class="datenew"></span></div>
										<div>
											<img class="dsR353" src="../images/sochi.jpg" alt="" border="0" /></div>
									</div>
									
									<span class="datenew">25.12.2013</span>
									<div class="TitleNews"></div>
									<div class="dsR75" style=" position: relative; -adbe-g: p,2,2;">
										<div>
											<img class="dsR74" src="../images/ListovkaPizza.jpg" alt="" height="207" width="625" border="0" /></div>
										<div class="dsR342" cslocked="cslocked" style="-adbe-c:c;">
											Новый дизайн листовки для пиццы &quot;el'Grande&quot;. <span class="datenew"></span></div>
									</div>
									<span class="datenew">23.12.2013</span>
									<div class="TitleNews"></div>
									<p>Компания "BIG-FISH" поздравляет Вас с наступающими праздниками и сообщает, что 31-го декабря приём заказов осуществляется до 21:00. Мы начинаем свою работу 1-го января с 14:00.</p> 
					
					<span class="datenew">1.12.2013</span>
									<div class="TitleNews"></div>
										<p>Компания "BIG-FISH" рада сообщить Вам, что в зону обслуживания компании вошли посёлок "Восточный", микрорайон "Янтарный" и микрорайон "1 мая".  </p>
					
					
					<span class="datenew">29.11.2013</span>
					<div class="TitleNews"></div>
					<div style="position:relative;width:810px;height:192px;-adbe-g:p,2,2;">
												<div style="position:absolute;top:0px;left:384px;width:425px;height:191px;">
													<img src="../images/burn.jpg" alt="" height="191" width="425" border="0" /></div>
												<div cslocked="cslocked" style="position:absolute;top:0px;left:0px;width:376px;height:172px;-adbe-c:c">
													Компания &quot;BIG-FISH&quot; рада сообщить о расширении ассортимента в нашем меню напитков. Теперь Вы можете заказать эенергетический напиток "Burn". 
													<span class="datenew"></span></div>
											</div>
											
					<span class="datenew">12.11.2013</span>
									<div class="TitleNews"></div>
										<p>Компания "BIG-FISH" рада сообщить Вам, что в зону обслуживания компании вошли районы "Матвеевское", "Нагатинский затон" и "Нагатино-Садовники".  </p>
					
					<span class="datenew">30.10.2013</span>
									<div class="TitleNews"></div>
									<div class="dsR2" style=" position: relative; -adbe-g: p,2,2;">
										<div>
											<img class="dsR5" src="../images/Pech.jpg" alt="" height="207" width="525" border="0" /></div>
										<div class="dsR6" cslocked="cslocked" style="-adbe-c:c;">
											Компания &quot;BIG-FISH&quot; рада сообщить Вам о запуске новой акции для пиццы &quot;el'Grande&quot;. Вырежите 7 одинаковых печатей, приложите чеки об оплате и получите любую пиццу 33 или 45 см. в подарок. <span class="datenew"></span></div>
									</div>
									<span class="datenew">30.10.2013</span>
									<div class="TitleNews"></div>
									<div class="dsR14" style=" position: relative; -adbe-g: p,2,2;">
										<div>
											<img class="dsR17" src="../images/Kupon.jpg" alt="" border="0" /></div>
										<div class="dsR19" cslocked="cslocked" style="-adbe-c:c;">
											Компания &quot;BIG-FISH&quot; рада сообщить о выходе ограниченной серии листовки. Каждая листовка содержит 3 купона со скидкой 7%. При заказе скажите что Вы являетесь владельцем купона, отдайте его при оплате заказа курьеру и получите скидку 7%. Скидка по купонам не суммируется. <span class="datenew"></span></div>
									</div>
									<span class="datenew">25.10.2013</span>
									<div class="TitleNews"></div>
										<p>Компания "BIG-FISH" рада сообщить Вам, что в зону обслуживания компании вошёл район Таганский и станция метро Римская.  </p>
					<span class="datenew">01.10.2013</span>
										<div class="TitleNews"></div>
										<p>Компания "BIG-FISH" рада сообщить Вам, что в зону обслуживания компании вошли микрорайон Капотня и г.Дзержинский.  </p>

						
					
					<span class="datenew">28.08.2013</span>
										<div class="TitleNews"></div>
										<p>Компания "BIG-FISH" рада сообщить Вам, что в зону обслуживания компании вошли районы Жулебино и Люберцы, а так же Рязанский проспект, платформа Карачарово, метро Выхино - выход на улицу Хлобыстова.  </p>
						
					
					<span class="datenew">07.08.2013</span>
										<div class="TitleNews"></div>
										<p>Компания "BIG-FISH" рада сообщить Вам, что в зону обслуживания вошли нижеследующие станции метро: м. Дубровка, м. Кожуховская, м. Автозаводская, м. Пролетарская, м. Крестьянская застава, а так же Совхоз им.Ленина, посёлок Развилка и город Щербинка.  </p>
						<span class="datenew">09.07.2013</span>
					<div class="TitleNews"></div>
					<div style="position:relative;width:810px;height:192px;-adbe-g:p,2,2;">
												<div style="position:absolute;top:0px;left:384px;width:425px;height:191px;">
													<img src="../images/Prozit.jpg" alt="" height="191" width="425" border="0" /></div>
												<div cslocked="cslocked" style="position:absolute;top:0px;left:0px;width:376px;height:172px;-adbe-c:c">
													Компания &quot;BIG-FISH&quot; рада сообщить о расширении ассортимента в нашем меню напитков. Теперь Вы можете заказать эксклюзивное светлое Австрийское пиво Прозит Бир. 
													<span class="datenew"></span></div>
											</div>
					
					<span class="datenew">26.03.2013</span>
										<div class="TitleNews"></div>
										<p>Только в Марьино!!! Теперь с 12:30 до 17:30 скидка 20% на всё меню &quot;BIG-FISH" и "el'Grande PIZZA", включая напитки. Минимальная сумма заказа при этом 600 рублей.  </p>
					
					<span class="datenew">26.03.2013</span>
					<div class="TitleNews"></div>
					<div style="position:relative;width:810px;height:192px;-adbe-g:p,2,2;">
												<div style="position:absolute;top:0px;left:384px;width:425px;height:191px;">
													<img src="../images/Shashlichki1.jpg" alt="" height="191" width="425" border="0" /></div>
												<div cslocked="cslocked" style="position:absolute;top:0px;left:0px;width:376px;height:172px;-adbe-c:c">
													Компания &quot;BIG-FISH&quot; рада сообщить о расширении ассортимента в нашем меню. Теперь Вы можете заказать вкусные шашлычки, приготовленные на гриле, с использованием наших фирменных соусов: Гребешок, Креветка, Мидии в беконе, Лосось, Угорь в беконе. 
													<span class="datenew"></span></div>
											</div>
					
					<span class="datenew">22.03.2013</span>
					<div class="TitleNews"></div>
					<p>Рады сообщить о долгожданном открытии службы доставки  "BIG-FISH&quot; в САО с 23.03.2013!!! В зону обслуживания компании войдут нижеследующие станции метро города Москвы: 1. м. Динамо 2. м. Аэропорт 3. м. Сокол  4. м. Войковская  5. м. Водный Стадион  6. м. Речной Вокзал  7. м. Тушинская  8. м. Сходненская 9. м. Планерная</p>
					
					<span class="datenew">15.01.2013</span>
										<div class="TitleNews"></div>
										<p>Рады сообщить о запуске нового сайта el'Grande PIZZA</a> - <a href="http://www.elgrande.su"><span class="ds1">www.elgrande.su</a> </span> Теперь Вы можете заказать блюда из меню через корзину на сайте.</p>
					
					<span class="datenew">07.01.2013</span>
										<div class="TitleNews"></div>
										<p>Компания "BIG-FISH" рада сообщить Вам,что в зону обслуживания вошли нижеследующие станции метро: м.Комсомольская, м.Красносельская.</p>
					
					<span class="datenew">19.12.2012</span>
										<div class="TitleNews"></div>
										<p>Компания "BIG-FISH" поздравляет Вас с наступающими праздниками и сообщает,что 31-го декабря приём заказов осуществляется до 20:30. Мы начинаем свою работу 1-го января с 13:30.</p> 
					
										
					<span class="datenew">13.12.2012</span>
										<div class="TitleNews"></div>
										<p>Только в ЦАО!!! Теперь с 16:00 до 00:00 скидка 20% на всё меню &quot;BIG-FISH" и "el'Grande PIZZA", включая напитки. Минимальная сумма заказа при этом 600 рублей </p>
										 
										
					
				
					<span class="datenew">11.12.2012</span>
										<div class="TitleNews"></div>
										<p>Компания "BIG-FISH" рада сообщить Вам о новых акциях при заказе от 1000 рублей блюд итальянской кухни. </p>
					
					
					
					
					<span class="datenew">21.11.2012</span>
					<div class="TitleNews"></div>
					<div style="position:relative;width:810px;height:192px;-adbe-g:p,2,2;">
												<div style="position:absolute;top:0px;left:384px;width:425px;height:191px;">
													<img src="../images/Shashlichki1.jpg" alt="" height="191" width="425" border="0" /></div>
												<div cslocked="cslocked" style="position:absolute;top:0px;left:0px;width:376px;height:172px;-adbe-c:c">
													Скоро!!! Компания &quot;BIG-FISH&quot; рада сообщить о расширении ассортимента в нашем меню. В ближайшее время Вы сможете заказать вкусные шашлычки, приготовленные на гриле, с использованием наших фирменных соусов: Гребешок в беконе, Креветка, Мидии в беконе, Лосось, Угорь в беконе. 
													<span class="datenew"></span></div>
											</div>
					
					
					<span class="datenew">10.10.2012</span>
					<div class="TitleNews"></div>
					<p>Долгожданное открытие службы доставки  "BIG-FISH&quot; в ЦАО!!! В зону обслуживания компании вошли нижеследующие станции метро центрального округа города Москвы: 1. м. Спортивная 2. м. Фрунзенская 3. м. Парк Культуры 4. м. Смоленская 5. м. Кропотнинская 6. м. Боровицкая 7. м. Арбатская 8. м. Александровский Сад 9. м.Библиотека им. Ленина 10. м. Октябрьская 11. м. Добрынинская 12. м. Серпуховская 13. м. Шаболовская 14. м. Павелецкая 15. м. Новокузнецкая 16. м. Третьяковская 17. м. Полянка 18. м. Охотный ряд 19. м. Площадь Революции 20. м.Театральная 21. м. Лубянка 22. м.Кузнецкий Мост 23. м. Трубная 24. м. Пушкинская 25. м. Чеховская 26. м. Тверская 27. м. Маяковская 28. м. Цветной Бульвар 29. м. Киевская 30. м. Международная 31. м. Выставочная 32. м. Барикадная 33. м. Краснопресненская 34. м. Улица 1905 35. м. Новослободская 36. м. Менделеевская 37. м. Достоевская 37. м. Суворовская площадь 38. м. Проспект Мира 39.  м Сухаревская  40. м. Цветной бульвар м. Сретенский бульвар 41. м. Кузнецкий Мост 42. м. Лубянка 43. м. Китай-Город 44. м. Театральная 45. Площадь Революции 46. м. Тургеневская 47. м. Чистые пруды  48. Красные Ворота  49. м. Курская  50. м. Таганская</p>
					
					<span class="datenew">29.09.2012</span>
					<div class="TitleNews"></div>
					<p>Скоро в ЦАО!!! В ближайшее время в зону обслуживания комании "BIG-FISH" войдут нижеследующие станции метро центрального округа города Москвы:
					1. м.Спортивная 2. м.Фрунзенская 3. м.Парк Культуры 4. м.Смоленская 5. м.Кропотнинская 6. м.Боровицкая 7. м.Арбатская 8. м.Александровский Сад 9. м.Библиотека им. Ленина 10. м.Октябрьская 11. м.Добрынинская 12. м.Серпуховская 13. м.Шаболовская 14. м.Павелецкая 15. м.Новокузнецкая 16. м.Третьяковская 17. м.Полянка 18. м.Охотный ряд 19. м.Площадь Революции 20. м.Театральная 21. м.Лубянка 22. м.Кузнецкий Мост 23. м.Трубная 24. м.Пушкинская 25. м.Чеховская 26. м.Тверская 27. м.Маяковская 28. м.Цветной Бульвар 29. м.Киевская 30. м.Международная 31. м.Выставочная 32. м.Барикадная 33. м.Краснопресненская 34. м.Улица 1905</p>
					
					
					<span class="datenew">29.09.2012</span>
					<div class="TitleNews"></div>
					
						<p>Компания “BIG-FISH” рада сообщить, что время работы увеличено на полчаса в будние дни. Теперь мы работаем для Вас ежедневно, без выходных с 10-30 до 00-00.</p>
				
											
					<span class="datenew">27.09.2012</span>
					<div class="TitleNews"></div>
					
					<p>Компания “BIG-FISH” рада сообщить о запуске нового сайта.</p>
						
					</div>
				</div>
				
				</div>
				<div id="Cart" style="display:none">	
					
				</div>
				<div class="Clear"></div>	
			<div id="Footer">
				<?php include('core/footer.inc') ?>
			</div>
			</div>
			<div class="BoobleL"></div>
			<div class="BoobleR"></div>
		</div>
		<!-- /Page centred -->
	</div>
</div>
</div>
</body>









